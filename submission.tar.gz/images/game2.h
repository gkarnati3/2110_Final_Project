/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 game2 game2.png 
 * Time-stamp: Friday 11/16/2018, 17:19:16
 * 
 * Image Information
 * -----------------
 * game2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME2_H
#define GAME2_H

extern const unsigned short game2[38400];
#define GAME2_SIZE 76800
#define GAME2_LENGTH 38400
#define GAME2_WIDTH 240
#define GAME2_HEIGHT 160

#endif

