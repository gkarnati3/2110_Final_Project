/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 game1 game1.png 
 * Time-stamp: Friday 11/16/2018, 17:05:50
 * 
 * Image Information
 * -----------------
 * game1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME1_H
#define GAME1_H

extern const unsigned short game1[38400];
#define GAME1_SIZE 76800
#define GAME1_LENGTH 38400
#define GAME1_WIDTH 240
#define GAME1_HEIGHT 160

#endif

