/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 tryagain tryagain.jpg 
 * Time-stamp: Friday 11/16/2018, 17:05:35
 * 
 * Image Information
 * -----------------
 * tryagain.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRYAGAIN_H
#define TRYAGAIN_H

extern const unsigned short tryagain[38400];
#define TRYAGAIN_SIZE 76800
#define TRYAGAIN_LENGTH 38400
#define TRYAGAIN_WIDTH 240
#define TRYAGAIN_HEIGHT 160

#endif

