/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x37 sad sad.png 
 * Time-stamp: Tuesday 11/20/2018, 19:57:52
 * 
 * Image Information
 * -----------------
 * sad.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAD_H
#define SAD_H

extern const unsigned short sad[1850];
#define SAD_SIZE 3700
#define SAD_LENGTH 1850
#define SAD_WIDTH 50
#define SAD_HEIGHT 37

#endif

