/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 title2 title2.png 
 * Time-stamp: Sunday 11/18/2018, 18:39:22
 * 
 * Image Information
 * -----------------
 * title2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE2_H
#define TITLE2_H

extern const unsigned short title2[38400];
#define TITLE2_SIZE 76800
#define TITLE2_LENGTH 38400
#define TITLE2_WIDTH 240
#define TITLE2_HEIGHT 160

#endif

